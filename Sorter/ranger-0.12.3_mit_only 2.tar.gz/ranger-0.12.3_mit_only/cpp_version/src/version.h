#ifndef RANGER_VERSION
#define RANGER_VERSION "0.12.3"
#endif
